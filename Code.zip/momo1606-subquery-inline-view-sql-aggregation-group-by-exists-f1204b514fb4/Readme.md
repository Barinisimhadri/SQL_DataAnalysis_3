Perform the below analysis:

1. Data analysis using Sub-query.
2. Inline view: List down all the employees along with department name and city where city is 'Roma'.
3. Aggregate Function: Min, Max, Count, Sum, Avg.
4. Combine different aggregated results in one row.
5. Department wise data analysis.
6. Filter and organize aggregated data.
7. Show department level details using aggregate function and inline view.
8. Data analysis using Sub-query and EXISTS clause.